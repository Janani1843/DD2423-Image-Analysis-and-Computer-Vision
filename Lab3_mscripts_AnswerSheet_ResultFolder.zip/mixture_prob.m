function [prob] = mixture_prob(image, K, L, mask)
rows = size(image,1);
cols = size (image,2);

I_re =im2double(reshape(image,rows*cols,3));
M = reshape(mask,rows*cols,1);

I_ones =I_re(find(M==1),:);
g = zeros(size(I_ones,1),K);

seed = 4321;

[segmentation, centers] = kmeans_graph(I_ones,K,L,seed);
cov = cell(K,1);
cov(:) = {rand*eye(3)};

wei = zeros(1,K);
for i = 1:K
    wei(i) = sum(segmentation == i)/size(segmentation,1);
end

g1 = zeros(rows*cols,K);

for i = 1 :L
    for k=1:K
        k_mean = centers(k,:);
        k_cov = cov{k};
        diff = bsxfun(@minus,I_ones, k_mean);
        g(:,k) = 1/sqrt(det(k_cov)*(2*pi)^3)*exp(-0.5*sum((diff*inv(k_cov).*diff),2));
    end
    
    p = bsxfun(@times,g,wei);
    norm = sum(p,2);
    p = bsxfun(@rdivide, p, norm);
    
    wei = sum(p,1)/size(p,1);
    
    for k = 1:K
        total = sum(p(:,k),1);
        center(k,:) = p(:,k)'*I_ones/total;
        diff = bsxfun(@minus,I_ones,centers(k,:));
        cov{k} = (diff' * bsxfun(@times,diff,p(:,k)))/total;
    end
end

for k = 1:K
    k_mean = center(k,:);
    k_cov = cov{k};
    diff = bsxfun(@minus,I_re,k_mean);
    g1(:, k) = 1 / sqrt(det(k_cov) * (2 * pi)^3) * exp(-1/2 * sum((diff * inv(k_cov) .* diff), 2));
end

prob_pre = sum(bsxfun(@times, g1, wei), 2);
prob = reshape(prob_pre, rows, cols, 1);



        
        
    




