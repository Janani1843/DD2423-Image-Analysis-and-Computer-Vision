function [ segmentation, centers ] = kmeans_segm(image, K, L, seed)
 [height,width, ~] = size(image);
 Ivec = double(reshape(image, width*height, 3));
 rng(seed);
 points = randperm(size(Ivec,1));
 for k = 1:K
     clusters(k,:) = Ivec(points(k),:);
 end
 
 dist = pdist2(Ivec,clusters,'euclidean');
 
 for l = 1:L
     [~,minIndex] = min(dist');
     for j = 1:K
         index = find(minIndex == j);
         clusters(j,:) = mean(Ivec(index,:),1);
         
     end
     
     dist = pdist2(Ivec,clusters,'euclidean');
 end
 
 [~,minIndex] = min(dist');
 segmentation = reshape(minIndex, height, width);
 
 %for i = 1:K
     %centers(i) = ceil(mean(find(segmentation == i)));
     
 %end
 
 centers = double(clusters);

end

