F = [zeros(60, 128); ones(8, 128); zeros(60, 128)] .* ...
[zeros(128, 48) ones(128, 32) zeros(128, 48)];
subplot(3,4,1);
showgrey(F);
title(sprintf('Scaled F - new image'));
Fhat = fft2(F);
subplot(3,4,2);
showfs(abs(Fhat));
title(sprintf('New FT'));