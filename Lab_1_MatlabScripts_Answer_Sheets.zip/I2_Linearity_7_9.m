F = [ zeros(56, 128) ;ones(16, 128); zeros(56, 128)];
G = F';
H = F + 2 * G;
subplot(3,3,1);
showgrey(F);
title(sprintf('F'))
subplot(3,3,2);
showgrey(G);
title(sprintf('G'))
subplot(3,3,3);
showgrey(H);
title(sprintf('H'))
Fhat = fft2(F);
Ghat = fft2(G);
Hhat = fft2(H);
subplot(3,3,4);
showgrey(log(1 + abs(Fhat)));
title(sprintf('Fhat'))
subplot(3,3,5);
showgrey(log(1 + abs(Ghat)));
title(sprintf('Ghat'))
subplot(3,3,6);
showgrey(log(1 + abs(Hhat)));
title(sprintf('Hhat'))
subplot(3,3,9);
showgrey(log(1 + abs(fftshift(Hhat))));
title(sprintf('FFTshift Hhat'))
figure(2);
surf(real(Fhat));
figure(3);
plot(abs(Fhat));
title(sprintf('abs(Fhat)'))
figure(4);
plot(log(1+abs(Fhat)));
title(sprintf('log(1+abs(Fhat))'))
ylim([0 10]);