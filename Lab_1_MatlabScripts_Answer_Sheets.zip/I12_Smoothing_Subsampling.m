img = phonecalc256;
smoothimg = img;
N=5;
for i=1:N
if i>1 % generate subsampled versions
img = rawsubsample(img);
%smoothimg = gaussfft(smoothimg, 1);
[smooth, mft] = ideal(smoothimg, 0.1, 'l');
smoothimg = rawsubsample(smooth);
end
subplot(2, N, i)
showgrey(img)
subplot(2, N, i+N)
showgrey(smoothimg)
end

function gaussFiltered = gaussfft(pic,t)
picfft = fft2(pic);
[xsize ysize] = size(picfft);
xmax = xsize/2;
ymax = ysize/2;
[x y] = meshgrid(xmax - xsize : xmax - 1, ymax - ysize : ymax - 1);
x_sqr = x.*x;
y_sqr = y.*y;
k = 1/(2*pi*t);
gaussKernel = k.*exp(-(x_sqr+y_sqr)./(2*t));
gaussKernelfft = fft2(fftshift(gaussKernel));
gaussFiltered =ifft2(gaussKernelfft.*picfft);
end 