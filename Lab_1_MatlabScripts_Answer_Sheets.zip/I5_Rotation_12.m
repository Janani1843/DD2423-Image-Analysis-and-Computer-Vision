F = [zeros(60, 128); ones(8, 128); zeros(60, 128)] .* ...
[zeros(128, 48) ones(128, 32) zeros(128, 48)];
figure(1);
subplot(2,3,1);
showgrey(F);
title(sprintf('Spatial image rotated by 0 deg'));
Fhat = fft2(F);
subplot(2,3,2);
showfs(Fhat);
title(sprintf('FFT'));
FhatBack = rot(fftshift(Fhat), 0 );
subplot(2,3,3);
showgrey(log(1+abs(FhatBack)));
title(sprintf('FFT rotated by 0 deg'));
figure(2);
subplot(2,3,1);
G = rot(F, 90 );
showgrey(G)
title(sprintf('Spatial image rotated by 90 deg'));
Ghat = fft2(G);
subplot(2,3,2);
showfs(Ghat);
title(sprintf('FFT'));
Hhat = rot(fftshift(Ghat), -90 );
subplot(2,3,3);
showgrey(log(1 + abs(Hhat)));
title(sprintf('FFT rotated by -90 deg'));
