F = [ zeros(56, 128); ones(16, 128); zeros(56, 128)];
subplot(3,4,1);
showgrey(F);
title(sprintf('F'))
G = F';
subplot(3,4,2);
showgrey(G);
title(sprintf('G'))
subplot(3,4,3);
showgrey(F .* G);
title(sprintf('Old signal'))
subplot(3,4,4);
H = F .* G;
showfs(fft2(F .* G));
title(sprintf('Old FT'))
Fhat = fft2(F);
subplot(3,4,5);
showfs(Fhat);
title(sprintf('Fourier Transform of F = Fhat'))
FhatShifted = fftshift(Fhat);
Ghat = fft2(G);
subplot(3,4,6);
showfs(Ghat);
title(sprintf('Fourier Transform of G = Ghat'))
GhatShifted = fftshift(Ghat);
Hhat = conv2(FhatShifted,GhatShifted,'same');
HhatNorm = Hhat/(128*128);
subplot(3,4,7);
showgrey(log(1+abs(HhatNorm)));
title(sprintf('Convolution of Fhat, Ghat - Normalized'))
