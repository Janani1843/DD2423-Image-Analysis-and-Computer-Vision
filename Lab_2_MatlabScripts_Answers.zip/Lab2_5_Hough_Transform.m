img = few256;
[linepar acc] = houghedgeline(img, 4, 10,256, 256,10);


