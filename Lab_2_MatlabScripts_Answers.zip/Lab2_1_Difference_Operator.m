%using sobel operator
clear;
clc;
deltax = [-1 0 1; -2 0 2; -1 0 1];
deltay = deltax';
tools = few256;
dxtools = conv2(tools, deltax, 'valid');
dytools = conv2(tools, deltay, 'valid');
subplot(1,3,1);
showgrey(tools);
title('Original image - tools');
subplot(1,3,2);
showgrey(dxtools);
title('Difference operator along X');
subplot(1,3,3);
showgrey(dytools);
title('Difference operator along Y');