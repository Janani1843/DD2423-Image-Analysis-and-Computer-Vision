house = godthem256;
scale = [0.0001, 1.0, 4.0, 16.0, 64.0];
for i = 1: length(scale)
    figure(1);
    subplot(1,5,i);
    showgrey(Lvvvtilde(discgaussfft(house, scale(i)), 'same') < 0);
    title(sprintf('Threshold = %d',scale(i)));
    figure(2);
    subplot(1,5,i);
    contour(Lvvtilde(discgaussfft(house, scale(i)), 'same'), [0 0]);
    axis('image');
    axis('ij');
    title(sprintf('Threshold = %d',scale(i)));
end
tools = few256;
scale = [0.0001, 1.0, 4.0, 16.0, 64.0];
for i = 1: length(scale)
    figure(3);
    subplot(1,5,i);
    showgrey(Lvvvtilde(discgaussfft(tools, scale(i)), 'same') < 0);
    title(sprintf('Threshold = %d',scale(i)));
    figure(4);
    subplot(1,5,i);
    imag = Lvvtilde(discgaussfft(tools, scale(i)), 'same')== 0;
    contour(Lvvtilde(discgaussfft(tools, scale(i)), 'same'), [0 0]);
    axis('image');
    axis('ij');
    title(sprintf('Threshold = %d',scale(i)));
end
