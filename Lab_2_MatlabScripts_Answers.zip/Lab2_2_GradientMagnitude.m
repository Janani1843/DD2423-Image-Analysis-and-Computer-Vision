%Gradient magnitude computation for the image "tools"
clear;
clc;
deltax = [-1 0 1; -2 0 2; -1 0 1];
deltay = deltax';
tools = few256;
dxtools = conv2(tools, deltax, 'valid');
dytools = conv2(tools, deltay, 'valid');
subplot(1,2,1);
showgrey(tools);
title('Original image - tools');
gradmagntools = sqrt(dxtools.^2 + dytools.^2);
subplot(1,2,2);
showgrey(gradmagntools);
title('Gradient magnitude - tools');
figure(2);
histogram(gradmagntools);
threshold = [20,40,60,80,100,120,130];
figure(3);
for i = 1: length(threshold)
    subplot(2,4,i);   
    showgrey((gradmagntools - threshold(i)) > 0);
    title(sprintf("Threshold at %d",threshold(i)));
end
%Gradient magnitude computation for the image "godthem256"
inpic = godthem256;
gradmagn = Lv(inpic,'valid');
figure(4);
subplot(1,2,1)
showgrey(inpic);
title('Original image - godthem');
subplot(1,2,2)
showgrey(gradmagn);
title('Gradient magnitude - godthem');
figure(5);
histogram(gradmagn);
figure(6);
threshold = [20,40,60,80,100,120,130];
for i = 1: length(threshold)
    subplot(2,4,i);   
    showgrey((gradmagn - threshold(i)) > 0);
    title(sprintf("Threshold at %d",threshold(i)));
end
%Gradient magnitude computation for the image "godthem256" with gaussian
%blur
inpic_smooth = gaussfft(inpic,16);
gradmagn_smooth = Lv(inpic_smooth,'valid');
figure(7);
subplot(1,2,1);
showgrey(inpic_smooth);
title("Gaussian smoothed image");
subplot(1,2,2);
showgrey(gradmagn_smooth);
title("Gradient magnitude of Gaussian smoothed image");
figure(8);
histogram(gradmagn_smooth);
figure(9);
threshold = [10,20,30,40,50,60,70,80];
for i = 1: length(threshold)
    subplot(2,4,i);   
    showgrey((gradmagn_smooth - threshold(i)) > 0);
    title(sprintf("Threshold at %d",threshold(i)));
end
