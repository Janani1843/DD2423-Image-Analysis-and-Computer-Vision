function [linepar acc] = houghline(curves, magnitude,nrho, ntheta, threshold, nlines)
    acc = zeros(nrho,ntheta);
    theta_x = linspace(-pi/2,pi/2,ntheta);
    M = sqrt((size(magnitude,1).^2) + (size(magnitude,2).^2));
    rho_y = linspace(-M,M,nrho);
    
    insize = size(curves, 2);
    trypointer = 1;
    numcurves = 0;
    outcurves = zeros(2,4*nlines);

while trypointer <= insize
  polylength = curves(2, trypointer);

  numcurves = numcurves + 1;

  trypointer = trypointer + 1;

  for polyidx = 1:polylength
    x = curves(2, trypointer);
    y = curves(1, trypointer);
    trypointer = trypointer + 1;
    val = magnitude(round(x), round(y));
    if val < threshold
        continue;
    end
    
    for theta_index= 1:ntheta
        theta = theta_x(theta_index);
        rho = x*cos(theta) + y*sin(theta);
        rho_index = find(rho_y <= rho, 1, 'last');
        acc(rho_index,theta_index) = acc(rho_index,theta_index)+log(val);
    end
  end
end
%acc = binsepsmoothiter(acc,0.5,10);

[pos value] = locmax8(acc);
[dummy indexvector] = sort(value);
nmaxima = size(value, 1);
linepar = zeros(2, nlines);
for idx = 1:nlines
rhoidxacc = pos(indexvector(nmaxima - idx + 1), 1);
thetaidxacc = pos(indexvector(nmaxima - idx + 1), 2);
theta = theta_x(thetaidxacc);
rho = rho_y(rhoidxacc);
linepar(:,idx) = [rho;theta];
   if (theta == 0)
       theta = 1 * 10^-06;
   end
   
    x0 = 0;
    y0 = (rho - x0 * cos(theta))./sin(theta);
    dx = M.^2;
    dy = (rho - dx * cos(theta))./sin(theta);
    
    outcurves(1, 4*(idx-1) + 1) = 0;          
    outcurves(2, 4*(idx-1) + 1) = 3;
    outcurves(2, 4*(idx-1) + 2) = x0 - dx;
    outcurves(1, 4*(idx-1) + 2) = y0 - dy;
    outcurves(2, 4*(idx-1) + 3) = x0;
    outcurves(1, 4*(idx-1) + 3) = y0;
    outcurves(2, 4*(idx-1) + 4) = x0+dx;
    outcurves(1, 4*(idx-1) + 4) = y0+dy;


end

linepar = outcurves;
    

end

