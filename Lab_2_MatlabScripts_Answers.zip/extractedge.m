function edgecurves = extractedge(inpic, scale, threshold, shape)

if(nargin < 4)
    shape = 'same';
end

Lv_first = Lv(discgaussfft(inpic,scale),shape);
Lvv = Lvvtilde(discgaussfft(inpic,scale),shape);
Lvvv = Lvvvtilde(discgaussfft(inpic,scale),shape);

Lv_mask = (Lv_first > threshold) - 0.5;
Lvvv_mask = (Lvvv < 0) - 0.5;

edgecurves = zerocrosscurves(Lvv, Lvvv_mask);
edgecurves = thresholdcurves(edgecurves, Lv_mask);

end

