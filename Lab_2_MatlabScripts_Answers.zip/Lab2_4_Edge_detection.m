house = godthem256;
tools = few256;
scale = 4;
threshold = [0,10,20,30,40,50];
for i = 1: length(threshold)
    figure(1);
    subplot(2,3,i);
    tools_output = extractedge(tools,scale,threshold(i),'same');
    overlaycurves(tools,tools_output);
    title(sprintf('Threshold = %d',threshold(i)));
    figure(2);
    subplot(2,3,i);
    house_output = extractedge(house,scale,threshold(i),'same');
    overlaycurves(house,house_output);
    title(sprintf('Threshold = %d',threshold(i)));
    
end
    
    