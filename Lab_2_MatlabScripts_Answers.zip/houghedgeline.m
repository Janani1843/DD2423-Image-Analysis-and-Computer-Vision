function [linepar acc] = houghedgeline(pic, scale, gradmagnthreshold,nrho, ntheta, nlines)

curves = extractedge(pic, scale, gradmagnthreshold, 'same');
magnitude = Lv(pic,'same');
[linepar acc] = houghline (curves, magnitude,nrho, ntheta,gradmagnthreshold, nlines);
acc = binsepsmoothiter(acc,0.5,1);
subplot(1,3,2);
overlaycurves(pic,linepar);
axis([1 size(pic,2) 1 size(pic,1)]);
title("Image space");
subplot(1,3,1);
overlaycurves(pic,curves);
title("Edges");
subplot(1,3,3);
showgrey(acc);
title("Hough space - smoothed");

end

